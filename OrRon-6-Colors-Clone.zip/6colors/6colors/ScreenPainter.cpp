
// this file handles all the gfx portion of the game
// its funding nextStep() is called from main and 
// it goes into endless loop calling the board class functions
// for the game algorithms when needed.


#include "stdafx.h"
#include "ScreenPainter.h"
#include <cstdlib>
#include <cstdio>
#include <iostream>

// resize the matrix to fit the board size 
ScreenPainter::ScreenPainter() 
{
	m_rectsScreen.resize(BOARD_SIZE);
	for (std::vector<std::vector<sf::RectangleShape>>::iterator it1 = m_rectsScreen.begin(); it1 != m_rectsScreen.end(); ++it1)
		(*it1).resize(BOARD_SIZE);
	// covers the edgaes of the traingles in the missle of the screen
	m_frame =
		sf::RectangleShape({ (float)((m_columns * 24) + 185), (float)50 });
	m_frame.setFillColor(sf::Color::Black);
}


ScreenPainter::~ScreenPainter()
{
}


// initializes texture array 
// and update the screen before the game begins
void ScreenPainter::initializeScreen(std::vector<sf::Texture> &texture)
{
	texture.resize(MAX_COLOR_NUM);
	texture[0].loadFromFile("robot.png");
	texture[1].loadFromFile("kid.jpg");
	texture[2].loadFromFile("restart.png");

	m_rectSize = RECTANGLE_SIZE;
	m_rects[RESTART].setOutlineColor(sf::Color::White);
	updateScreen();
}

// every chnage need to update screen with all traingles 
void ScreenPainter::updateScreen()
{
	//update the colors after the player and computer move using iterator
	for (std::vector<std::vector<sf::RectangleShape>>::iterator it1 = m_rectsScreen.begin(); it1 != m_rectsScreen.end(); ++it1)
	{
		for (std::vector<sf::RectangleShape>::iterator it2 = (*it1).begin(); it2 != (*it1).end(); ++it2)
		{		
			int i = (int) distance(m_rectsScreen.begin(), it1);
			int j = (int) distance((*it1).begin(), it2);
			(*it2) =
				sf::RectangleShape({ (float)m_rectSize, (float)m_rectSize });
			//The position of even raws is different from odd
			if (i%2 != 0)
				(*it2).setPosition((float)2 + (j * (m_rectSize + 14)),
					(float)185 + (i * (m_rectSize )));
			else 
				(*it2).setPosition((float)19 + (j * (m_rectSize + 14)),
				      (float)185 + (i * (m_rectSize )));
			m_frame.setPosition(2, 150);
			(*it2).setRotation(45);
			
			//update the colors for each traingle
			switch (m_game.getColor(i, j))
			{
			case GREEN:
				(*it2).setFillColor(sf::Color::Green);
				break;
			case RED:
				(*it2).setFillColor(sf::Color::Red);
				break;
			case ORANGE:
				(*it2).setFillColor(sf::Color::Magenta);
				break;
			case BLUE:
				(*it2).setFillColor(sf::Color::Blue);
				break;
			case PURPLE:
				(*it2).setFillColor(sf::Color::White);
				break;
			case YELLOW:
				(*it2).setFillColor(sf::Color::Yellow);
				break;
			}
			if (m_game.getOwner(i,j) == PLAYER || m_game.getOwner(i, j) == COMP)
				(*it2).setOutlineColor(sf::Color::White);
			else
				(*it2).setOutlineColor(sf::Color::Black);
			(*it2).setOutlineThickness(2);
		}
	}

	// update the menue of the colors and restart button
	for (array<sf::RectangleShape, MAX_COLOR_NUM>::iterator it1 = m_rects.begin(); it1 != m_rects.end(); ++it1)
	{
		int i = (int) distance(m_rects.begin(), it1);
		if (i != RESTART)
		{
			*it1 = sf::RectangleShape({ 50, 50 });
			(*it1).setPosition((float)10 + (i * 70), (float)10);
		}
		else
		{
			(*it1) = sf::RectangleShape({ 80, 50 });
			(*it1).setPosition((float)150 + (i * 70), (float)10);
			(*it1).setOutlineColor(sf::Color::Black);
			(*it1).setOutlineThickness(1);
		}
		switch (i)
		{
		case GREEN:
			(*it1).setFillColor(sf::Color::Green);
			break;
		case RED:
			(*it1).setFillColor(sf::Color::Red);
			break;
		case ORANGE:
			(*it1).setFillColor(sf::Color::Magenta);
			break;
		case BLUE:
			(*it1).setFillColor(sf::Color::Blue);
			break;
		case PURPLE:
			(*it1).setFillColor(sf::Color::White);
			break;
		case YELLOW:
			(*it1).setFillColor(sf::Color::Yellow);
			break;
		}
		if (i != RESTART)
		{
			(*it1).setOutlineColor(sf::Color::Cyan);
			(*it1).setTexture(NULL);
			(*it1).setOutlineThickness(10);
		}
	}
}


// main fucntion of the class which takes care of the screen 
// called from main function 
int ScreenPainter::nextStep()
{
	unsigned int width, length;

	std::vector<sf::Texture> texture;
	initializeScreen(texture);

	width = m_columns * (m_rectSize + 4) + 185;
	length = m_lines * (m_rectSize+4) + 100;

	sf::RenderWindow window(sf::VideoMode(width,length ),"Six Colors");

	sf::Font font;
	font.loadFromFile("Gabriola.TTF");

	// this text is updtaed with % of ownership of the board each turn 
	char str[100];
	sprintf(str, "Player: %.2f %% Computer: %.2f %%", m_game.getPercent(PLAYER), m_game.getPercent(COMP));

	sf::Text txt(str, font, 20);
	txt.setFillColor(sf::Color::White);
	txt.setOutlineThickness(10);
	txt.setOutlineColor(sf::Color::Black);
	txt.setStyle(sf::Text::Bold);
	txt.setCharacterSize(50);
	txt.setPosition((float)50, (float)100);

	// this text is when game ends with the winer 
	char strWin[100];
	
	sf::Text txtWin(str, font, 20);
	txtWin.setFillColor(sf::Color::Green);
	txtWin.setOutlineThickness(10);
	txtWin.setOutlineColor(sf::Color::Black);
	txtWin.setStyle(sf::Text::Bold);
	txtWin.setCharacterSize(30);
	txtWin.setPosition((float)100, (float)70);


	while (window.isOpen())
	{
		window.clear();
		m_rects[RESTART].setTexture(&texture[2]);
		// draw the menu of the colors and restart 
		for (array<sf::RectangleShape, MAX_COLOR_NUM>::iterator it0 = m_rects.begin(); it0 != m_rects.end(); ++it0)
			window.draw(*it0);
		//draw the whole board with iterators on the matrix
		for (std::vector<std::vector<sf::RectangleShape>>::iterator it1 = m_rectsScreen.begin(); it1 != m_rectsScreen.end(); ++it1)
			for (std::vector<sf::RectangleShape>::iterator it2 = (*it1).begin(); it2 != (*it1).end(); ++it2)
				window.draw(*it2);
		// draw the black frame that hides the edges of the traingles
		window.draw(m_frame);
		sprintf(str, "Player: %.2f %%  Computer: %.2f %%", m_game.getPercent(PLAYER),
			m_game.getPercent(COMP));
		txt.setString(str);
		// draw the % of the ownership for player and computer
		window.draw(txt);

		// checkes of if game ended and one of the players got more than 50%
		if (m_game.getPercent(PLAYER) > 50 || m_game.getPercent(COMP) > 50)
		{
			if (m_game.getPercent(PLAYER) > 50)
				sprintf(strWin, " Well Done you Won!! - press Restart or Exit ");
			else
				sprintf(strWin, " You Lost Computer Won!! - press Restart or Exit");
			txtWin.setString(strWin);
			window.draw(txtWin);
			m_gameOver = true;
		}

		// mark the color menue - which player owns right now which color 
		m_rects[m_game.getColor(PLAYER)].setOutlineColor(sf::Color::White);
		m_rects[m_game.getColor(PLAYER)].setTexture(&texture[1]);
		m_rects[m_game.getColor(COMP)].setOutlineColor(sf::Color::White);
		m_rects[m_game.getColor(COMP)].setTexture(&texture[0]);
		if (m_state == CLOSE)
		{
			window.close();
			return 0;
		}
		window.display();
		sf::Event event;
		eventHandle(event,window,texture);
	}
	window.close();
	return 1;
}

// called after every event happened, new color chosen by the player or
// restart was asked or game is over 
void ScreenPainter::handleRects(int i, std::vector<sf::Texture> & texture)
{	
	if (i == RESTART)
	{
		m_game.resetBoard();
		updateScreen();
		m_gameOver = false;
		return;
	}
	if (m_gameOver)
		return;
	if (i == m_game.getColor(PLAYER) || i == m_game.getColor(COMP))
		return;

	// update the board going through all the steps after a player move
	m_game.resetVisit();
	m_game.setColor(PLAYER, (Color)i);  

	// the main algorithm to paint the new added traingle after a color change
	m_game.paintBoardWithColor(BOARD_SIZE - 1, 0, (Color)i, PLAYER, true);

	// find the color which gives the computer player the highest number of traiangles
	Color color = m_game.findBestColorComp();
	m_game.setColor(COMP, (Color)color);

	// after finding the color apply it to the baord for the computer same as player 
	m_game.paintBoardWithColor(0, BOARD_SIZE - 1, (Color)color, COMP, true);
	m_game.setPercent();

	// mark in the color menue which color belong to which player
	m_rects[i].setOutlineColor(sf::Color::White);
	m_rects[i].setTexture(&texture[1]);
	m_rects[color].setOutlineColor(sf::Color::White);
	m_rects[color].setTexture(&texture[0]);

	// after all changes update the screen
	updateScreen();

}

// handle three type of events: chosing a new color, closing the window 
// and restart the game 
void ScreenPainter::eventHandle(sf::Event & event, sf::RenderWindow &window,
							    std::vector<sf::Texture> & texture)
{
	static bool control = false;
	static int i = 0;
	static int j = 1;
	static float totalScales[3] = { 1,1,1 };
	window.waitEvent(event);
	{
		switch (event.type)
		{
		case sf::Event::Closed:
			m_state = CLOSE;
			window.close();
			break;
		case sf::Event::MouseButtonPressed:
			const auto coords = window.mapPixelToCoords({ event.mouseButton.x, event.mouseButton.y });
			for (unsigned int i = 0; i < MAX_COLOR_NUM; i++)
				if (m_rects[i].getGlobalBounds().contains(coords))
					handleRects(i,texture);
			break;
		
		}
	}
}
