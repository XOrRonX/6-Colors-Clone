#pragma once

#define _CRT_SECURE_NO_WARNINGS

#ifdef _DEBUG
#pragma comment ( lib , "sfml-main-d.lib" )
#pragma comment ( lib , "sfml-system-d.lib" )
#pragma comment ( lib , "sfml-window-d.lib" )
#pragma comment ( lib , "sfml-graphics-d.lib" )
#elif defined (NDEBUG)
#pragma comment ( lib , "sfml-main.lib" )
#pragma comment ( lib , "sfml-system.lib" )
#pragma comment ( lib , "sfml-window.lib" )
#pragma comment ( lib , "sfml-graphics.lib" )
#else
#error "Unrecognized configuration!"
#endif

//================================include=============================

#include <SFML/Graphics.hpp>
#include "stdafx.h"
#include <vector>
#include <iostream>
#include <ctime>    // For time()
#include <cstdlib>  // For srand() and rand()
#include <Windows.h>
#include <array>

using std::cin;
using std::cout;
using std::vector;
using std::array;
using std::distance;
using std::advance;



const int BOARD_SIZE = 20;
const int MAX_COLOR_NUM = 7;
const int RECTANGLE_SIZE = 20;
// graphical const for size of screen and rectangles
const int MAX_WIDTH = 800;
const int MAX_REC_SIZE = 50;
typedef enum  { VERT = 0, HORIZ = 1 , NON  = 2 } Split;
typedef enum  { GREEN = 0, RED = 1, ORANGE = 2, BLUE = 3,
					 PURPLE = 4, YELLOW = 5, RESTART = 6} Color;
typedef enum  { PLAYER = 0, COMP = 1, NO_OWNER = 2} Owner;
enum painterState { BASIC = 0, SAVE = 1, CLEAN_SHEET = 2, CLOSE = 3 };


