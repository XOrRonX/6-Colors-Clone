
//this file implement the logic of the game on a board
//the board halds matrix of triangles which holds the status and 
// progress of the gaem


#include "stdafx.h"
#include "board.h"

//resize the baord acording the the board size
board::board()
{
	m_board.resize(BOARD_SIZE);
	for (std::vector<std::vector<square>>::iterator it1 = m_board.begin(); it1 != m_board.end(); ++it1)
		(*it1).resize(BOARD_SIZE);
	resetBoard();
}

board::~board()
{
}

// intialize the baord - called when the game start but also from restart
void board::resetBoard()
{
	srand((unsigned int)time(0));
	for (std::vector<std::vector<square>>::iterator it1 = m_board.begin(); it1 != m_board.end(); ++it1)
	{
		for (std::vector<square>::iterator it2 = (*it1).begin(); it2 != (*it1).end(); ++it2)
		{
			Sleep(2);
			(*it2).setColor((Color)(rand() % 6));
			(*it2).initOwner(NO_OWNER);
		}
	}
	m_compOwned = 1;
	m_playerOwned = 1;
	m_compPercent = 0;
	m_playerPercent = 0;
	m_playerColor = m_board[BOARD_SIZE - 1][0].initOwner(PLAYER);
	m_compColor = m_board[0][BOARD_SIZE - 1].initOwner(COMP);
}



// for the computer looks for the best next color that gives the computer
// the higest number of triangles
Color board::findBestColorComp()
{
	float OriginalCompOwned = m_compOwned;
	Color maxColor = m_compColor;
	float maxCompOwned = m_compOwned;
	for (int i = 0 ; i < MAX_COLOR_NUM; i++)
	{
		m_compOwned = OriginalCompOwned;

		// if the color is the same as current computer or player then ignore
		if (i == m_compColor || i == m_playerColor)
			continue;

		// before the recursive call update all triangles as not visited
		resetVisit();

		// recursive function counting all the triangles that can be owned for 
		//this color. the last parameter means to not change the board as this
		// is just checking what can be dene
		paintBoardWithColor(0, BOARD_SIZE - 1, (Color)i, COMP, false);
		if (m_compOwned > maxCompOwned)
		{
			// remmebering the best color till now 
			maxCompOwned = m_compOwned;
			maxColor = (Color)i;
		}
	}
	
	//return the data member to its original value before the function  
	m_compOwned = OriginalCompOwned;

	resetVisit();

	//return the best colo
	return maxColor;
}

// the heart of baord algorithm to grow the triangles for new color
// this is a recursive function, for each tringle call recursively 
// the right neighbors. This function is used both by the player and computer 
void board::paintBoardWithColor(int i, int j, Color color, Owner owner,bool change)
{
	bool newSquare = false;
	// a recursive stop condition 
	if (i < 0 || j > BOARD_SIZE - 1 || i > BOARD_SIZE - 1 || j < 0)
		return;
	else
	{
		vector<vector<square>>::iterator it1 = m_board.begin();
		advance(it1, i);
		vector<square>::iterator it2 = (*it1).begin();
		advance(it2, j);

		// if I can color this triangle then I want to call recursively to
		// all its neigbors, if cannot coloe this triangles then return
		if ((*it2).newColor(color, owner, newSquare, change))
		{
			if (newSquare)  // if a new saure getting colored count it
			{
				if (owner == PLAYER)
					m_playerOwned++;
				if (owner == COMP)
					m_compOwned++;
			}

			// call the neighbors 
			paintBoardWithColor((i - 1), j, color, owner, change);
			paintBoardWithColor((i + 1), j, color, owner, change);

			//because the traingles are not straight the neighbors are different
			//in even and odd raws
			if (i % 2 == 0)
			{
				paintBoardWithColor((i - 1), (j + 1), color, owner, change);
				paintBoardWithColor((i + 1), (j + 1), color, owner, change);	
			}
			else
			{
				paintBoardWithColor((i - 1), (j - 1), color, owner, change);
				paintBoardWithColor((i + 1), (j - 1), color, owner, change);
			}
		}
	}
}


float board::getPlayerPercent()
{
	return (float) (m_playerOwned / (BOARD_SIZE*BOARD_SIZE));
}

float board::getCompPercent()
{
	return (float) (m_compOwned / (BOARD_SIZE*BOARD_SIZE));
}

//reset the visit bit for next recursive run
void board::resetVisit()
{
	for (std::vector<std::vector<square>>::iterator it1 = m_board.begin(); it1 != m_board.end(); ++it1)
		for (std::vector<square>::iterator it2 = (*it1).begin(); it2 != (*it1).end(); ++it2)
			(*it2).resetVisit();
}

// set the new player or computer color
void board::setColor(Owner owner, Color color)
{
	if (owner == PLAYER)
		m_playerColor = color;
	if (owner == COMP)
		m_compColor = color;
}

// get the color of each owner
Color board::getColor(Owner owner)
{
	if (owner == PLAYER)
		return m_playerColor;
	return m_compColor;
}

// get the percentage of the baord for the owner 
float board::getPercent(Owner owner)
{
	if (owner == PLAYER)
		return m_playerPercent;
	return m_compPercent; 
}


Color board::getColor(int i, int j)
{
	return m_board[i][j].getColor();
}

Owner board::getOwner(int i, int j)
{
	return m_board[i][j].getOwner();
}

void board::setPercent()
{
	m_playerPercent = ((m_playerOwned / (BOARD_SIZE*BOARD_SIZE)) * 100);
	m_compPercent =  (m_compOwned / (BOARD_SIZE*BOARD_SIZE)) * 100;
}
