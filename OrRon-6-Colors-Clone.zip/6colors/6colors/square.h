
// This square class manage one square and all its states.

#pragma once

#include "common.h"

class square
{
public:
	square();
	~square();

	//update a square either its color to be like color or its ownership
	// to be like owner.
	bool newColor(Color color, Owner owner,bool & newSquare, bool change);
	Color initOwner(Owner owner);
	void resetVisit();
	void setColor(Color color);
	Color getColor();
	Owner getOwner();
private:
	Color m_color;
	Owner m_owner = NO_OWNER;
	bool m_visited = false;
};

