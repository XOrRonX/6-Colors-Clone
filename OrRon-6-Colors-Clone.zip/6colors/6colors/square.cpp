#include "stdafx.h"
#include "square.h"



square::square()
{
}

void square::setColor(Color color)
{
	m_color = color;
}

Color square::initOwner(Owner owner)
{
	m_owner = owner;
	return m_color;
}

square::~square()
{
}

// change the triangle color or ownership - adding that triangle 
// to the ownership of owner 
bool square::newColor(Color color, Owner owner, bool & newSquare, bool change)
{
	if (m_visited)
		return false;
	m_visited = true;
	if (m_owner == owner)
	{
		if (change) // change is false when computer is looking for best color
		{
			m_color = color;
			setColor(m_color);
		}
		return true;
	}
	else
		if (m_color == color)
		{
			if (change) // change is false when computer is looking for best color
				m_owner = owner;
			newSquare = true;
			return true;
		}
	return false;
}

void square::resetVisit()
{
	m_visited = false;
}

Color square::getColor()
{
	return m_color;
}

Owner square::getOwner()
{
	return m_owner;
}