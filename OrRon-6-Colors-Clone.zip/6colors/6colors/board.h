

//the board class implement the logic of the game on a board
//the board halds matrix of triangles which holds the status and 
// progress of the gaem



#pragma once


#include "common.h"
#include "square.h"

class board
{
public:
	board();
	~board();

	// The recursive function which is finding all the new triangles 
	void paintBoardWithColor(int i, int j, Color color, Owner owner, bool change);
	float getPlayerPercent();
	float getCompPercent();

	// Reset the visit indicator for all triangles for the recursive run 
	void resetVisit();

	// for the computer look for the best color to get highest number of triangles
	Color findBestColorComp();
	void setColor(Owner owner, Color color);
	Color getColor(Owner owner);
	float getPercent(Owner owner);
	void  setPercent();
	Color getColor(int i, int j);
	Owner getOwner(int i, int j);

	// used for restarting the board in case restart was picked 
	void resetBoard();

private:
	vector<vector<square>> m_board;
	float m_playerOwned = 1;
	float m_compOwned = 1;
	Color m_playerColor;
	Color m_compColor;
	float m_playerPercent;
	float m_compPercent;
};



