
// this file handles all the gfx portion of the game
// its funding nextStep() is called from main and 
// it goes into endless loop calling the board class functions
// for the game algorithms when needed.


#pragma once
#define _CRT_SECURE_NO_WARNINGS

#include "common.h"
#include "board.h"
#include "square.h"
#include <cstdlib>
#include <cstdio>
#include <iostream>


class ScreenPainter
{
public:

	ScreenPainter();
	~ScreenPainter();

	// the main function of the class which is managing all the flows
	int nextStep();

private:

	// Array of the menue
	array<sf::RectangleShape, MAX_COLOR_NUM> m_rects;

	// used to cover the upper edges of the triangles 
	sf::RectangleShape m_frame;

	// matrix of triangles used for the graphics
	vector<vector<sf::RectangleShape>> m_rectsScreen;

	// holds the lines and the columns of the screen
	unsigned int m_lines = BOARD_SIZE, m_columns = BOARD_SIZE;

	// record if request is to exit the game
	int m_state;

	// the board of the game
	board m_game;

	// size of the rectangle
	unsigned int m_rectSize;

	// intialize all the SFML objects required to display the screen
	void initializeScreen(std::vector<sf::Texture> &texture);


	//wait for events from the screen and handle them 
	void eventHandle(sf::Event & event, sf::RenderWindow &window,
					std::vector<sf::Texture> & texture);

	// take care of the menue of colors and restart 
	void handleRects(int i, std::vector<sf::Texture> & texture);

	void updateScreen();

	bool m_gameOver = false;
};

